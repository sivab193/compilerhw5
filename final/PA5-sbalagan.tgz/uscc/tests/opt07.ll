; ModuleID = 'main'

@.str = private unnamed_addr constant [4 x i8] c"%d\0A\00"

declare i32 @printf(i8*, ...)

define i32 @main() {
entry:
  %array = alloca [3 x i32], align 8
  %0 = getelementptr inbounds [3 x i32]* %array, i32 0, i32 0
  %1 = getelementptr inbounds i32* %0, i32 0
  store i32 1, i32* %1
  %2 = getelementptr inbounds i32* %0, i32 1
  store i32 3, i32* %2
  %3 = getelementptr inbounds i32* %0, i32 2
  store i32 5, i32* %3
  %4 = getelementptr inbounds i32* %0, i32 1
  %5 = load i32* %4
  br label %while.cond

while.cond:                                       ; preds = %while.body, %entry
  %Phi = phi i32 [ %dec, %while.body ], [ 10, %entry ]
  %gt = icmp sgt i32 %Phi, 0
  br i1 %gt, label %while.body, label %while.end

while.body:                                       ; preds = %while.cond
  %add = add i32 %5, 10
  %6 = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([4 x i8]* @.str, i32 0, i32 0), i32 %add)
  %dec = sub i32 %Phi, 1
  br label %while.cond

while.end:                                        ; preds = %while.cond
  %7 = getelementptr inbounds i32* %0, i32 2
  %8 = load i32* %7
  %9 = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([4 x i8]* @.str, i32 0, i32 0), i32 %8)
  ret i32 0
}
