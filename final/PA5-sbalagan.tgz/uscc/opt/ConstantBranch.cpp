//
//  ContantBranch.cpp
//  uscc
//
//  Implements Constant Branch Folding opt pass.
//  This converts conditional branches on constants to
//  unconditional branches.
//
//---------------------------------------------------------
//  Copyright (c) 2014, Sanjay Madhav
//  All rights reserved.
//
//  This file is distributed under the BSD license.
//  See LICENSE.TXT for details.
//---------------------------------------------------------
#include "Passes.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wconversion"
#include <llvm/IR/Function.h>
#include <llvm/IR/Instructions.h>
#include <llvm/IR/Constants.h>
#pragma clang diagnostic pop
#include <set>

using namespace llvm;

namespace uscc
{
namespace opt
{
	
bool ConstantBranch::runOnFunction(Function& F)
{
	bool changed = false;
	
	// Collect candidate conditional branches with constant conditions
	std::set<BranchInst*> removeSet;
	
	for (Function::iterator blockIter = F.begin(); blockIter != F.end(); ++blockIter)
	{
		for (BasicBlock::iterator instrIter = blockIter->begin();
			 instrIter != blockIter->end(); ++instrIter)
		{
			BranchInst* brInst = dyn_cast<BranchInst>(instrIter);
			if (brInst && brInst->isConditional())
			{
				ConstantInt* ci = dyn_cast<ConstantInt>(brInst->getCondition());
				if (ci)
				{
					removeSet.insert(brInst);
				}
			}
		}
	}
	
	// Now process each candidate
	for (std::set<BranchInst*>::iterator it = removeSet.begin();
		 it != removeSet.end(); ++it)
	{
		BranchInst* brInst = *it;
		ConstantInt* ci = dyn_cast<ConstantInt>(brInst->getCondition());
		
		// In LLVM, conditional branch: true -> successor(0), false -> successor(1)
		BasicBlock* takenBB;
		BasicBlock* notTakenBB;
		
		if (ci->isOne()) // true
		{
			takenBB = brInst->getSuccessor(0);
			notTakenBB = brInst->getSuccessor(1);
		}
		else // false
		{
			takenBB = brInst->getSuccessor(1);
			notTakenBB = brInst->getSuccessor(0);
		}
		
		// Create unconditional branch to the taken successor
		BranchInst::Create(takenBB, brInst);
		
		// Remove this block as predecessor of the not-taken successor
		notTakenBB->removePredecessor(brInst->getParent());
		
		// Erase the old conditional branch
		brInst->eraseFromParent();
		
		changed = true;
	}
	
	return changed;
}

void ConstantBranch::getAnalysisUsage(AnalysisUsage& Info) const
{
	// This pass requires ConstantOps to run first
	Info.addRequired<ConstantOps>();
	// Do NOT setPreservesCFG because this pass alters the CFG
}
	
} // opt
} // uscc

char uscc::opt::ConstantBranch::ID = 0;
