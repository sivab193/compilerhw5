//
//  DeadBlocks.cpp
//  uscc
//
//  Implements Dead Block Removal optimization pass.
//  This removes blocks from the CFG which are unreachable.
//
//---------------------------------------------------------
//  Copyright (c) 2014, Sanjay Madhav
//  All rights reserved.
//
//  This file is distributed under the BSD license.
//  See LICENSE.TXT for details.
//---------------------------------------------------------
#include "Passes.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wconversion"
#include <llvm/IR/Function.h>
#include <llvm/IR/CFG.h>
#include <llvm/ADT/DepthFirstIterator.h>
#pragma clang diagnostic pop
#include <set>

using namespace llvm;

namespace uscc
{
namespace opt
{
	
bool DeadBlocks::runOnFunction(Function& F)
{
	bool changed = false;
	
	// Step 1: Use DFS to identify all reachable blocks from entry
	std::set<BasicBlock*> reachable;
	BasicBlock* entry = &F.getEntryBlock();
	
	// df_ext_begin/df_ext_end perform a depth-first traversal, inserting
	// visited nodes into the provided set
	for (df_ext_iterator<BasicBlock*> it = df_ext_begin(entry, reachable),
		 e = df_ext_end(entry, reachable); it != e; ++it)
	{
		// The iterator automatically populates the reachable set
	}
	
	// Step 2: Collect all unreachable blocks
	std::vector<BasicBlock*> unreachableSet;
	for (Function::iterator bi = F.begin(); bi != F.end(); ++bi)
	{
		BasicBlock* bb = &*bi;
		if (reachable.find(bb) == reachable.end())
		{
			unreachableSet.push_back(bb);
		}
	}
	
	// Step 3: For each unreachable block, notify all successors to remove
	// it as a predecessor
	for (unsigned i = 0; i < unreachableSet.size(); ++i)
	{
		BasicBlock* bb = unreachableSet[i];
		for (succ_iterator si = succ_begin(bb), se = succ_end(bb);
			 si != se; ++si)
		{
			(*si)->removePredecessor(bb);
		}
	}
	
	// Step 4: Drop all references (to allow deletion) and erase from function
	for (unsigned i = 0; i < unreachableSet.size(); ++i)
	{
		unreachableSet[i]->dropAllReferences();
	}
	
	for (unsigned i = 0; i < unreachableSet.size(); ++i)
	{
		unreachableSet[i]->eraseFromParent();
		changed = true;
	}
	
	return changed;
}
	
void DeadBlocks::getAnalysisUsage(AnalysisUsage& Info) const
{
	// This pass must execute after ConstantBranch
	Info.addRequired<ConstantBranch>();
}

} // opt
} // uscc

char uscc::opt::DeadBlocks::ID = 0;
